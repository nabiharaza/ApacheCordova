<a name="1.2.7"></a>
## [1.2.7](https://github.com/hypery2k/cordova-email-plugin/compare/v1.2.6...v1.2.7) (2018-02-16)



<a name="1.2.6"></a>
## [1.2.6](https://github.com/hypery2k/cordova-email-plugin/compare/v1.2.5...v1.2.6) (2017-01-03)


### Bug Fixes

* **isAvailable-error:** fix callback error on newer android ([171b99b](https://github.com/hypery2k/cordova-email-plugin/commit/171b99b)), closes [#39](https://github.com/hypery2k/cordova-email-plugin/issues/39)



<a name="1.2.5"></a>
## [1.2.5](https://github.com/hypery2k/cordova-email-plugin/compare/v1.2.4...v1.2.5) (2016-12-24)


### Bug Fixes

* **package:** fix version error ([#38](https://github.com/hypery2k/cordova-email-plugin/issues/38)) ([1992e95](https://github.com/hypery2k/cordova-email-plugin/commit/1992e95))



<a name="1.2.4"></a>
## [1.2.4](https://github.com/hypery2k/cordova-email-plugin/compare/v1.2.3...v1.2.4) (2016-12-18)



<a name="1.2.3"></a>
## [1.2.3](https://github.com/hypery2k/cordova-email-plugin/compare/v1.2.1...v1.2.3) (2016-12-17)



<a name="1.2.1"></a>
## [1.2.1](https://github.com/hypery2k/cordova-email-plugin/compare/v1.2.0...v1.2.1) (2016-11-06)


### Bug Fixes

* **iOS:** Fix isAvailable null error ([#23](https://github.com/hypery2k/cordova-email-plugin/issues/23)) ([78ec84c](https://github.com/hypery2k/cordova-email-plugin/commit/78ec84c))



<a name="1.2.0"></a>
# [1.2.0](https://github.com/hypery2k/cordova-email-plugin/compare/v1.1.1...v1.2.0) (2016-11-03)



<a name="1.1.1"></a>
## [1.1.1](https://github.com/hypery2k/cordova-email-plugin/compare/0.8.3...v1.1.1) (2016-06-27)



<a name="0.8.3"></a>
## [0.8.3](https://github.com/hypery2k/cordova-email-plugin/compare/v1.1.0...0.8.3) (2016-03-01)



<a name="1.1.0"></a>
# [1.1.0](https://github.com/hypery2k/cordova-email-plugin/compare/v1.0.0...v1.1.0) (2015-12-16)



<a name="1.0.0"></a>
# [1.0.0](https://github.com/hypery2k/cordova-email-plugin/compare/0.8.2...v1.0.0) (2015-10-29)



<a name="0.8.2"></a>
## [0.8.2](https://github.com/hypery2k/cordova-email-plugin/compare/v0.8.2...0.8.2) (2015-03-01)



<a name="0.8.2"></a>
## [0.8.2](https://github.com/hypery2k/cordova-email-plugin/compare/0.8.1...v0.8.2) (2015-02-28)



<a name="0.8.1"></a>
## [0.8.1](https://github.com/hypery2k/cordova-email-plugin/compare/0.8.0...0.8.1) (2014-04-06)



<a name="0.8.0"></a>
# [0.8.0](https://github.com/hypery2k/cordova-email-plugin/compare/0.7.2...0.8.0) (2014-03-02)



<a name="0.7.2"></a>
## [0.7.2](https://github.com/hypery2k/cordova-email-plugin/compare/0.7.1...0.7.2) (2014-03-01)



<a name="0.7.1"></a>
## [0.7.1](https://github.com/hypery2k/cordova-email-plugin/compare/0.7.0...0.7.1) (2013-12-19)



<a name="0.7.0"></a>
# [0.7.0](https://github.com/hypery2k/cordova-email-plugin/compare/0.6.0...0.7.0) (2013-12-05)



<a name="0.6.0"></a>
# [0.6.0](https://github.com/hypery2k/cordova-email-plugin/compare/0.4.2...0.6.0) (2013-11-17)



<a name="0.4.2"></a>
## [0.4.2](https://github.com/hypery2k/cordova-email-plugin/compare/0.4.1...0.4.2) (2013-11-17)



<a name="0.4.1"></a>
## [0.4.1](https://github.com/hypery2k/cordova-email-plugin/compare/0.4.0...0.4.1) (2013-11-03)



<a name="0.4.0"></a>
# [0.4.0](https://github.com/hypery2k/cordova-email-plugin/compare/0.2.1...0.4.0) (2013-08-20)



<a name="0.2.1"></a>
## [0.2.1](https://github.com/hypery2k/cordova-email-plugin/compare/0.2.0...0.2.1) (2013-08-15)



<a name="0.2.0"></a>
# 0.2.0 (2013-08-12)



