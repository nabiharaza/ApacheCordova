/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var x1 = 0,
    y1 = 0,
    z1 = 0,
    x2 = 0,
    y2 = 0,
    batteryStatus = null,
    isPlugged = null,
    z2 = 0;


var app = {
    // Application Constructor

    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
        document.getElementById("changeColor").addEventListener('click', this.setRandomColor);

        

        // this.batteryButton = document.getElementById('battery');
        // this.batteryButton.addEventListener('click', this.showBatteryLevel;
        
        document.getElementById("battery").addEventListener('click', this.showBatteryLevel);
        
        this.x = document.getElementById('x');
        this.y = document.getElementById('y');
        this.z = document.getElementById('z');
        this.w = false;

        this.button = document.getElementById('watch');
        this.button.addEventListener('click', this.watch.bind(this));
    },

    showBatteryLevel: function() {
        navigator.getBattery().then(function(battery) {
            alert("Battery level : "+(battery.level*100)+"%");
       
        });
    },

    options: {
        frequency: 3000
    },
    watch: function() {
        console.log('Start watching accelerometer', this.w);

        if (this.w) {
            navigator.accelerometer.clearWatch(this.w);
            this.w = false;
            this.button.className = '';
            this.button.innerText = 'Start';
        } else {
            this.w = navigator.accelerometer.watchAcceleration(this.success.bind(this), this.error.bind(this), {
                frequency: 200
            });
            this.button.className = 'stop';
            this.button.innerText = 'Stop';
        }
    },

    success: function(a) {
        var t = new Date(a.timestamp);
        this.x.innerText = a.x;
        this.y.innerText = a.y;
        this.z.innerText = a.z;
        x1 = this.x.innerText;
        y1 = this.y.innerText;
        z1 = this.z.innerText;

        sensitivity = 20;
        var accelerationChange = {
            x: 0,
            y: 0,
            z: 0
        };

        previousAcceleration = {
            x: 0,
            y: 0,
            z: 0
        };

        if (previousAcceleration.x !== null) {

            accelerationChange.x = Math.abs(previousAcceleration.x - a.x);
            accelerationChange.y = Math.abs(previousAcceleration.y - a.y);
            accelerationChange.z = Math.abs(previousAcceleration.z - a.z);
        }

        previousAcceleration = {
            x: a.x,
            y: a.y,
            z: a.z
        };

        if (accelerationChange.x + accelerationChange.y + accelerationChange.z > sensitivity) {
            var x = Math.floor(Math.random() * 256);
            var y = Math.floor(Math.random() * 256);
            var z = Math.floor(Math.random() * 256);
            var bgColor = "rgb(" + x + "," + y + "," + z + ")";
            document.body.style.background = bgColor;
            navigator.camera.getPicture(onSuccess, onFail, {  
              quality: 5, 
              destinationType: Camera.DestinationType.DATA_URL 
           });  
           
           function onSuccess(imageData) { 
              var image = document.getElementById('myImage'); 
              //image.src = "data:image/jpeg;base64," + imageData; 
            //alert(imageData);
            let img = 'base64:img.jpg//'+imageData;


            alert(img); 
            


              cordova.plugins.email.isAvailable(
    function (isAvailable) {
        alert("Email");
        cordova.plugins.email.addAlias('gmail', 'com.google.android.gm');
              cordova.plugins.email.open({
                    to:      'neelkirit@gmail.com',
                    subject: 'Greetings',
                    attachments: img,
                    body:    '<h1>Pic from Cordova App</h1><br>',
                    isHtml:  true
                });
    }
);
                
           }  
           
           function onFail(message) { 
              alert('Failed because: ' + message); 
           } 
            
        }
    },

    error: function(error) {
        console.error('ERROR Accelerometer: ', error);
    },
    onDeviceReady: function() {
        //window.addEventListener('batterystatus', onBatteryStatus, false);
        this.receivedEvent('deviceready');
    },

    setRandomColor() {
        alert("jweijweijf");
        var x = Math.floor(Math.random() * 256);
        var y = Math.floor(Math.random() * 256);
        var z = Math.floor(Math.random() * 256);
        var bgColor = "rgb(" + x + "," + y + "," + z + ")";
        bgColor;
        document.body.style.background = bgColor;
    },

    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
    },


};



app.initialize();